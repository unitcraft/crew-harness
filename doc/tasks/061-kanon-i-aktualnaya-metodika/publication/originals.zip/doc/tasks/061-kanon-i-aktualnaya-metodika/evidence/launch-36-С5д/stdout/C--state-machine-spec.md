ABSENT at immutable commit
